****************************************************************

Rollout	:      CT_REPORT_00303_V.001                               13-06-2019

Description: 

Issues Fixed: Issue(s) fixed, one per line.

****************************************************************

Release notes for the fixes in this rollout.

****************************************************************
            I N S T A L L A T I O N   N O T E S             
****************************************************************

1. Login as the environment's administrator.
2. Check for the below mentioned directories, create if not available
	$ cd $LESDIR/rollouts | if not available mkdir $LESDIR/rollouts
	$ mkdir CT_REPORT_00303_V.001 
	
3. Traverse to temp directory in the local server 
	$ cd $LESDIR/temp
	$ mkdir $LESDIR/temp/CT_REPORT_00303_V.001 
	$ cd $LESDIR/temp/CT_REPORT_00303_V.001 
	
4. Copy the rollout distribution file into the environment's temporary directory and extract it as follows
	$ cp CT_REPORT_00303_V.001.tar $LESDIR/rollouts/CT_REPORT_00303_V.001/CT_REPORT_00303_V.001.tar
	$ cd $LESDIR/rollouts/CT_REPORT_00303_V.001
	$ tar xvf CT_REPORT_00303_V.001.tar

5. Shut down the RP environment.
	$ rp stop
	
6. Install the rollout.
	$ perl rollout.pl CT_REPORT_00303_V.001

7.  Start up the environment.
    $ rp start

